<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head><!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Gym Shop</title>
  </head>
  
<body>
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #003566;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">SajShop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav col-md-11">
        <a class="nav-link " aria-current="page" href="index.php">Home</a>
        <a class="nav-link " href="proteini.php">Protein</a>
        <a class="nav-link " href="kreatin.php">Creatin</a>
        
      </div>
      <div class="col-md-1 "  style="color: white;">
        <a href="korpa.php" id="cart"><i class="fa fa-shopping-cart icon-color"> Korpa</i> <span class="badge icon-color"></span></a>
      </div>
    </div>
  </div>

</nav>
<h3 style="text-align: center;">Vaši proizvodi</h3><br>
<?php
$ukupno=0;
$lista="";
echo "<div class='row'>
		<div class='col-md-5'></div>";
if(isset($_SESSION['protein1'])){
	$protein1=$_SESSION['protein1'];
	echo $protein1[0]." Cena :".$protein1[1].",00 RSD"."<br>";
	$lista.=$protein1[0];
	$ukupno+=$protein1[1];
}//u svakom bloku ista promenjiva, ili samo kod f-ja?
if(isset($_SESSION['protein2'])){
	$protein2=$_SESSION['protein2'];
	echo $protein2[0]." Cena :".$protein2[1].",00 RSD"."<br>";
	$lista.=$protein2[0];
	$ukupno+=$protein2[1];
}
if(isset($_SESSION['protein3'])){
	$protein3=$_SESSION['protein3'];
	echo $protein3[0]." Cena :".$protein3[1].",00 RSD"."<br>";
	$lista.=$protein3[0];
	$ukupno+=$protein3[1];
}
if(isset($_SESSION['kreatin1'])){
	$kreatin1=$_SESSION['kreatin1'];
	echo $kreatin1[0]." Cena :".$kreatin1[1].",00 RSD"."<br>";
	$lista.=$kreatin1[0];
	$ukupno+=$kreatin1[1];
}//u svakom bloku ista promenjiva, ili samo kod f-ja?
if(isset($_SESSION['kreatin2'])){
	$kreatin2=$_SESSION['kreatin2'];
	echo $kreatin2[0]." Cena :".$kreatin2[1].",00 RSD"."<br>";
	$lista.=$kreatin2[0];
	$ukupno+=$kreatin2[1];
}
if(isset($_SESSION['kreatin3'])){
	$kreatin3=$_SESSION['kreatin3'];
	echo $kreatin3[0]." Cena :".$kreatin3[1].",00 RSD"."<br>";
	$lista.=$kreatin3[0];
	$ukupno+=$kreatin3[1];
}
echo "Ukupno za uplatu : ".$ukupno.",00 RSD";
echo "</div>"
?>

<?php
// Konekcija na bazu
function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
  }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$imee = $_POST["ime"];
  	$email = $_POST["email"];
	$adresa = $_POST["adresa"];

	if($imee=="" || $email=="" || $adresa=="")
	{
		$message = "Morate uneti sve podatke";
	echo "<script type='text/javascript'>alert('$message');</script>";//NEMAM VALIDACIJU ZA MEJL
	}
	else{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gym";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO porudzbine (ime_prezime,email,adresa,lista_proizvoda,ukupno_za_uplatu)
VALUES ('$imee', '$email', '$adresa','$lista','$ukupno')";

if ($conn->query($sql) === TRUE) {
	$message = "Uspešno ste uneli podatke";
	echo "<script type='text/javascript'>alert('$message');
	window.location.href = 'index.php';</script>";

session_destroy();

	
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
}
?>
<div class="row">
	<div class="col-md-3"></div>
	<div style="text-align: center; margin-left:-15pt;" class="col-md-6 centriraj">
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			<section style="margin-left:-37pt;"> Ime i prezime <input type="text" name="ime"></section>
			<section style="margin-left:-2pt;"> Adresa <input type="text" name="adresa"><br></section>
			<section style="margin-left:2.5pt;"> E-mail <input type="text" name="email"></section><br>
			<section style="margin-left:35pt;"><input type="submit" name="dugme3" class="btn btn-primary" value="Buy" id="Protein3"></section>
		</form>
	</div>
	<div class="col-md-3"></div>
</div>

<!-- Remove the container if you want to extend the Footer to full width. -->
<div class="container-fluid p-0">

  <footer class="text-center text-lg-start fixed-bottom" style="background-color: #003566;">
    <div class="container d-flex justify-content-center py-5">
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-facebook-f icon-color"></i>
      </button>
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-pinterest icon-color"></i>
      </button>
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-instagram icon-color"></i>
      </button>
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-twitter icon-color"></i>
      </button>
    </div>

    <!-- Copyright -->
    <div class="text-center text-white p-3" style="background-color: #001d3d;">
      © 2020 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">MDBootstrap.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  
</div>
<!-- End of .container -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  
</body>

</html>