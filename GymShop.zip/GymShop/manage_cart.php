<?php
//if($_SERVER["REQUEST_METHOD"]=="POST"){
  //  if(isset($_POST['Add_To_Cart'])){
   //     if(isset($_SESSION['cart'])){
//
   //     }
   //     else{

   //     }
 //   }
//}
?>