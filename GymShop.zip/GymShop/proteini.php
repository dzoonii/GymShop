<?php 
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  /*$protein1=$cenap1=$protein2=$protein3=$cenap2=$cenap3="";
  $protein1 = ($_POST["protein1"]);
  $cenap1 = ($_POST["cena1"]);
  $protein2 = ($_POST["protein2"]);
  $cenap2 = ($_POST["cena2"]);
  $protein3 = ($_POST["protein3"]);
  $cenap3 = ($_POST["cena3"]);
  */
  if (isset($_POST['dugme1'])) {
    $protein1 = ($_POST["protein1"]);
    $cenap1 = ($_POST["cena1"]);
    $ukupno = array($protein1,$cenap1);
    $_SESSION['protein1']=$ukupno;
  }
  if (isset($_POST['dugme2'])) {
    $protein2 = ($_POST["protein2"]);
    $cenap2 = ($_POST["cena2"]);
    $ukupno1 = array($protein2,$cenap2);
    $_SESSION['protein2']=$ukupno1;
  }
  if (isset($_POST['dugme3'])) {
    $protein3 = ($_POST["protein3"]);
    $cenap3 = ($_POST["cena3"]);
    $ukupno2 = array($protein3,$cenap3);
    $_SESSION['protein3']=$ukupno2;
  }
  
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}





?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Gym Shop</title>
  </head>
  
<body>
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #003566;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">SajShop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav col-md-11">
        <a class="nav-link " aria-current="page" href="index.php">Home</a>
        <a class="nav-link active" href="proteini.php">Protein</a>
        <a class="nav-link " href="kreatin.php">Creatin</a>
        
      </div>
      <div class="col-md-1 "  style="color: white;">
        <a href="korpa.php" id="cart"><i class="fa fa-shopping-cart icon-color"> Korpa</i> <span class="badge icon-color"></span></a>
      </div>
    </div>
  </div>

</nav>

  <div class="row odvoj">
    <div class="col-md-1"></div>
        <div class="card col-md-2" style="width: 14rem;">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
          <img src="slike/slik6.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">THE NUTRITION ALL IN 1 GAINER 2000 GRAMA</h5>
            <input type="hidden" name="protein1" value="Gainer1">
            <input type="hidden" name="cena1" value="3560">
            <p class="card-text">3.560,00 RSD</p>
            <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
            <input type="submit" name="dugme1" class="btn btn-primary" value="Buy" id="Protein1">
          </div> 
        </form>
        </div>
    <div class="col-md-2"></div>
    <div class="card col-md-2" style="width: 14rem;">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <img src="slike/slik2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">THE AMINO WHEY HYDRO PROTEIN 3.500 G</h5>
        <input type="hidden" name="protein2" value="Amino">
        <input type="hidden" name="cena2" value="7690">
        <p class="card-text">7.690,00 RSD</p>
        <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
        <input type="submit" name="dugme2" class="btn btn-primary" value="Buy" id="Protein2">
      </div>
    </form>
    </div>
    <div class="col-md-2"></div>
    <div class="card col-md-2" style="width: 14rem;">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <img src="slike/slik5.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">THE BASIC 100% WHEY PROTEIN 1800 GRAMA</h5>
        <input type="hidden" name="protein3" value="Basic">
        <input type="hidden" name="cena3" value="3990">
        <p class="card-text">3.990,00 RSD</p>
        <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
        <input type="submit" name="dugme3" class="btn btn-primary" value="Buy" id="Protein3">
      </div>
    </form>
    </div>
    <div class="col-md-1"></div>
</div>

<!-- Remove the container if you want to extend the Footer to full width. -->
<div class="container-fluid p-0">

  <footer class="text-center text-lg-start" style="background-color: #003566;">
    <div class="container d-flex justify-content-center py-5">
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-facebook-f icon-color"></i>
      </button>
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-pinterest icon-color"></i>
      </button>
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-instagram icon-color"></i>
      </button>
      <button type="button" class="btn btn-lg btn-floating mx-2" style="background-color: #000814;">
        <i class="fa fa-twitter icon-color"></i>
      </button>
    </div>

    <!-- Copyright -->
    <div class="text-center text-white p-3" style="background-color: #001d3d;">
      © 2020 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">MDBootstrap.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  
</div>
<!-- End of .container -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  
</body>
</html>